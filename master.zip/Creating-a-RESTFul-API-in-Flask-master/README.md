# Creating-a-RESTFul-API-in-Flask
for : Creating a RESTFul API in Flask With JSON Web Token Authentication and Flask-SQLAlchemy
https://www.youtube.com/watch?v=WxGBoY5iNXY
