SQLALCHEMY_DATABASE_URI = 'mysql+pymysql://root:12345@localhost:3306/flaskapi'
SECRET_KEY = 'Oracle is a registered trademark of Oracle Corporation and/or itsaffiliates. Other names may be trademarks of their respectiveowners.'
TOKEN_EXPIRATION = 30 * 24 * 3600
